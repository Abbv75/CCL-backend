# V1 mise en place du MVP

## V1.1 mise en place de la base de donnees

### V1.1.0 mise en de la db

- Mise en place des migrations
- Mise en place des models
- Mise en place des seeders

### V1.1.1 mise en place des controllers, routers et documentation Swagger

- Mise en place des controllers
- Mise en place du router
- Mise en place de la documentation swagger
